package com.skill.base.domain;

import lombok.Data;

import javax.persistence.Column;
import java.util.List;

/**
 * Author: SkillChen
 * Create Time:2018/9/14 14:47
 **/
@Data
public class PageEntity {

    @Column
    private Integer total;//总记录数

    @Column
    private  Integer pageNum;//页面

    @Column
    private  Integer pageSize;//页大小

    @Column
    private List<?> data;//数据集
}
