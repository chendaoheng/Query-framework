package com.skill.base.until;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Author: SkillChen
 * Create Time:2018/9/13 14:08
 **/
public class QueryUntil {

    /**
     * 根据参数想要的参数名，获取参数值。
     * @param map
     * @param params
     * @return resultMap
     */
    public static Map<String, String[]> getParamMap(Map<String, String[]> map, String params){
        String[] paramNames= params.split(",");
        Map<String, String[]> resultMap=new HashMap<String, String[]>();
        for(String paramName:paramNames){
            resultMap.put(paramName,map.get(paramName));
        }
        return  resultMap;
    }

    /**
     * 转换为驼峰
     *
     * @param unHumpName
     * @return humpName
     */
    public static String humpName(String unHumpName) {
        StringBuilder result = new StringBuilder();
        if (unHumpName != null && unHumpName.length() > 0) {
            boolean flag = false;
            for (int i = 0; i < unHumpName.length(); i++) {
                char ch = unHumpName.charAt(i);
                if ("_".charAt(0) == ch) {
                    flag = true;
                } else {
                    if (flag) {
                        result.append(Character.toUpperCase(ch));
                        flag = false;
                    } else {
                        result.append(Character.toLowerCase(ch));
                    }
                }
            }
        }
        return result.toString();
    }

    public static List<Map<String, Object>> getHumpMap(List<Map<String, Object>> list){
        if (list!=null) {
            List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();
            Map<String, Object> resultMap;
            for (Map<String, Object> m : list) {
                resultMap = new HashMap<String, Object>();
                for (String k : m.keySet()) {
                    resultMap.put(humpName(k), m.get(k));
                }
                resultList.add(resultMap);
            }
            return resultList;
        }else {
            return null;
        }
    }

}
