package com.skill.base.service;

import com.skill.base.domain.PageEntity;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

/**
 * Author: SkillChen
 * Create Time:2018/9/12 12:00
 **/
public interface QueryService {

    List<Map<String, Object>> query(HttpServletRequest request);

    List<Map<String, Object>> agileQuery(HttpServletRequest request);

    PageEntity agileQueryPage(HttpServletRequest request);

    PageEntity queryPage(HttpServletRequest request);

    boolean setSqlMap();
}
