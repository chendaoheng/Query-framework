package com.skill.base.until;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.util.List;

/**
 * Author: SkillChen
 * Create Time:2018/8/2 10:47
 **/
public class HttpServletUtil {

    /**
     * 通过list获取json并返回给前端
     * @param response http响应
     * @param list 待加工的集合
     */
    public static void printJsonByList(HttpServletResponse response, List<?> list){
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json; charset=utf-8");
        try {
            PrintWriter out = response.getWriter();
            JSONArray resultJson = JSONArray.fromObject(list);
            out.println(resultJson);
            out.flush();
        }catch (Exception e){
           e.printStackTrace();
        }
    }

    public static void printJsonObject(HttpServletResponse response,Object obj){
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json; charset=utf-8");
        try {
            PrintWriter out = response.getWriter();
            JSONObject resultJson = JSONObject.fromObject(obj);
            out.println(resultJson);
            out.flush();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
