package com.skill.base.service.impl;

import com.skill.base.dao.QueryDao;
import com.skill.base.domain.PageEntity;
import com.skill.base.domain.QueryEntity;
import com.skill.base.service.QueryService;
import com.skill.base.until.QueryUntil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.FutureTask;

/**
 * Author: SkillChen
 * Create Time:2018/9/12 17:00
 **/
@Service
public class QueryServiceImpl implements QueryService {

    public QueryServiceImpl(){
        init();
    }
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Resource
    private QueryDao queryDao;

    private static ConcurrentHashMap<String,QueryEntity> sqlMap;

    @Autowired
    private LocalContainerEntityManagerFactoryBean entityManagerFactory;

    private void init(){
        FutureTask<String> task = new FutureTask<String>(new Callable<String>(){
            @Override
            public String call(){
                setSqlMap(); //使用另一个线程来执行该方法，会避免占用Tomcat的启动时间
                return "Collection Completed";
            }
        });
        new Thread(task).start();
    }

    private Integer getCount(HttpServletRequest request){
        String qid=request.getParameter("qid");
        List<Object> paramList=new ArrayList<Object>();
        if(qid==null){
            logger.info("请求没有包含必要参数pid，查询失败！！");
            return null;
        }
        QueryEntity entity= sqlMap.get(qid);
        if(entity!=null){
            String[] paramNames;
            if(entity.getCountParam()!=null) {
                paramNames = entity.getCountParam().split(",");
                for (String paramName:paramNames) {
                    paramList.add(request.getParameter(paramName));
                }
            }
            logger.info(entity.getCountSql());
            logger.info(entity.getCountParam());
            return jdbcTemplate.queryForObject(entity.getCountSql(),paramList.toArray(),java.lang.Integer.class);
        }else{
            logger.info("没有找到qid对应的脚本！！！");
            return null;
        }
    }

    @Autowired
    public boolean setSqlMap(){
        sqlMap=new ConcurrentHashMap<String, QueryEntity>();
        QueryEntity queryEntity =queryDao.getQueryEntityByQid("1");
        EntityManager em =  entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
        Query query = em.createNativeQuery(queryEntity.getEntitySql(),QueryEntity.class);
        List<QueryEntity> list = query.getResultList();
        for(QueryEntity entity:list){
            sqlMap.put(entity.getQid(),entity);
        }
        return true;
    }

    @Override
    public  List<Map<String, Object>> query(HttpServletRequest request){
        return QueryUntil.getHumpMap(agileQuery(request));
    }
    @Override
    public List<Map<String, Object>> agileQuery(HttpServletRequest request){
        String qid=request.getParameter("qid");
        List<Object> paramList=new ArrayList<Object>();
        if(qid==null){
            logger.info("请求没有包含必要参数pid，查询失败！！");
            return null;
        }
        QueryEntity entity= sqlMap.get(qid);
        if(entity!=null){
            String[] paramNames;
            if(entity.getEntityParam()!=null) {
                paramNames = entity.getEntityParam().split(",");
                for (String paramName :paramNames) {
                    paramList.add(request.getParameter(paramName));
                }
            }
            logger.info(entity.getEntitySql());
            logger.info(entity.getEntityParam());
            return jdbcTemplate.queryForList(entity.getEntitySql(),paramList.toArray());
        }else{
            logger.info("没有找到qid对应的脚本！！！");
            return null;
        }
    }

    @Override
    public PageEntity agileQueryPage(HttpServletRequest request) {
        return getPage(request,"agileQuery");
    }


    @Override
    public PageEntity queryPage(HttpServletRequest request) {
        return getPage(request,"query");
    }

    private PageEntity getPage(HttpServletRequest request,String type){
        PageEntity pageEntity= new PageEntity();
        pageEntity.setTotal(getCount(request));
        String pageNum=request.getParameter("pageNum");
        String pageSize=request.getParameter("pageSize");
        if(pageNum==null||pageSize==null) {
            logger.info("queryPage:"+"分页查询功能必须带上分页参数,才能正常分页");
        }else{
            pageEntity.setPageNum(Integer.parseInt(pageNum));
            pageEntity.setPageSize(Integer.parseInt(pageSize));
            if("query".equals(type)){
                pageEntity.setData(query(request));
            }else if("agileQuery".equals(type)) {
                pageEntity.setData(agileQuery(request));
            }
        }
        return pageEntity;
    }

}
