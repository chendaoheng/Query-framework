package com.skill.base.dao;

import com.skill.base.domain.QueryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * Author: SkillChen
 * Create Time:2018/9/12 11:57
 **/
@Repository
public interface QueryDao extends JpaRepository<QueryEntity,Long> {

    @Query(value = "select * From tb_query t where qid=?1",nativeQuery = true)
    QueryEntity getQueryEntityByQid(String qid);

}
