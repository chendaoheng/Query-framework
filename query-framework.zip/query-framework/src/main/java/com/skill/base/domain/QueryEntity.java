package com.skill.base.domain;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Author: SkillChen
 * Create Time:2018/9/12 11:13
 **/
@Data
@EqualsAndHashCode(callSuper = false)
@Entity(name = "TB_QUERY")
public class QueryEntity {
    @Id
    @Column
    private String qid;//主键

    @Column
    private String comments;//功能描述

    @Column
    private String entitySql;//查询实体

    @Column
    private String countSql;//查询条数

    @Column
    private String entityParam;//查询实体所需参数

    @Column
    private String countParam;//查询条数所需参数

    @Column
    private String stats;//状态（enable可用，disable禁用）

    @Column
    private String createDate;//创建日期

    @Column
    private String updateDate;//修改日期

}
