package com.skill.base.controller;

import com.skill.base.domain.PageEntity;
import com.skill.base.service.QueryService;
import com.skill.base.until.HttpServletUtil;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Author: SkillChen
 * Create Time:2018/9/13 11:45
 **/
@Controller
public class QueryController {

    @Resource
    private QueryService queryService;

    /**
     * 针对select * 形式或者sql，获得的json字符串其键值对的key为驼峰式
     * @param request 请求
     * @param response 响应
     */
    @ResponseBody
    @RequestMapping(value="/query", produces = "text/plain;charset=utf-8")
    public void query(HttpServletRequest request, HttpServletResponse response) {
        List list= queryService.query(request);
        HttpServletUtil.printJsonByList(response,list);
    }


    /**
     * 快速查询，不追求key为驼峰式的时候，用这个方法会更加高效
     * @param request 请求
     * @param response 响应
     */
    @ResponseBody
    @RequestMapping(value="/agileQuery", produces = "text/plain;charset=utf-8")
    public void agileQuery(HttpServletRequest request,HttpServletResponse response) {
        List list= queryService.agileQuery(request);
        HttpServletUtil.printJsonByList(response,list);
    }

    /**
     * 机遇query的分页功能。
     * @param request 请求
     * @param response 响应
     */
    @ResponseBody
    @RequestMapping(value="/queryPage", produces = "text/plain;charset=utf-8")
    public void queryPage(HttpServletRequest request, HttpServletResponse response) {
        PageEntity pageEntity= queryService.queryPage(request);
        HttpServletUtil.printJsonObject(response,pageEntity);
    }

    /**
     * 刷新sql缓存
     * @param response 响应
     */
    @ResponseBody
    @RequestMapping(value="/refreshMap", produces = "text/plain;charset=utf-8")
    public void setSqlMap(HttpServletResponse response) {
        boolean flag=queryService.setSqlMap();
        Map<String,Object> map= new HashMap<String, Object>();
        map.put("执行结果：",flag);
        HttpServletUtil.printJsonObject(response,map);
    }
}
