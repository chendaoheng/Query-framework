-- Create table
create table TB_USER
(
  id        NUMBER,
  user_name VARCHAR2(10),
  user_sex  VARCHAR2(5),
  user_qq   NUMBER
);
-- Add comments to the table
comment on table TB_USER
  is '用户表';
-- Add comments to the columns
comment on column TB_USER.id
  is '主键id';
comment on column TB_USER.user_name
  is '姓名';
comment on column TB_USER.user_sex
  is '性别';
comment on column TB_USER.user_qq
  is 'qq';
--Add some rows;
insert into tb_user(id,user_name,user_sex,user_qq)
select 1,'陈星','男',1023744555 from dual
union all
select 2,'张三','男',1023744556 from dual
union all
select 3,'李四','男',1023744557 from dual;
commit;
