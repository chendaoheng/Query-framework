/**
* Author: skill
* 说明：查询qid必须大写并唯一。添加前最好查询id是否存在
* 复制别的脚步第一时间修改qid，以免覆盖了别的脚本
*/
declare
v_qid varchar2(20);--查询id
v_comments varchar2(100);--功能说明
entitySql varchar2(4000);--查询实体sql
countSql varchar2(4000);--查询总数sql
entityParam varchar2(1000);--查询实体参数
countParam varchar2(1000);--查询总数参数
v_stats varchar2(8);--禁用状态
exist number;
begin
  --填写内容;这部分内容自行修改
  v_qid:='1';
  v_comments:='加载sql到缓存';
  entitySql:='select * from tb_query where STATS=''ENABLE''';
  countSql:='select count(1) from tb_query STATS=''ENABLE''';
  entityParam:='';
  countParam:='';
  v_stats:='ENABLE';--只能是ENABLE或者DISABLE
  --判断并插入数据;这部分代码最好不要修改
  select count(1) into exist from tb_query where QID=v_qid;
  if exist=0 then
    begin
      insert into tb_query(QID,COMMENTS,ENTITY_SQL,COUNT_SQL,ENTITY_PARAM,COUNT_PARAM,STATS)
      values(v_qid,v_comments,entitySql,countSql,entityParam,countParam,v_stats);
      commit;
      dbms_output.put_line('新增成功');
    end;
  else
    begin
   	  update tb_query set QID=qid,COMMENTS=v_comments,ENTITY_SQL=entitySql,ENTITY_PARAM=entityParam,
      COUNT_SQL=countSql,COUNT_PARAM=countParam,STATS=v_stats,UPDATE_DATE=sysdate
      where QID=v_qid;
      commit;
      dbms_output.put_line('修改成功');
    end;
  end if;
end;
/****************************第二个脚本*********************************************/
/**
* Author: skill
* 说明：查询qid必须大写并唯一。添加前最好查询id是否存在
* 复制别的脚步第一时间修改qid，以免覆盖了别的脚本
*/
declare
v_qid varchar2(20);--查询id
v_comments varchar2(100);--功能说明
entitySql varchar2(4000);--查询实体sql
countSql varchar2(4000);--查询总数sql
entityParam varchar2(1000);--查询实体参数
countParam varchar2(1000);--查询总数参数
v_stats varchar2(8);--禁用状态
exist number;
pageParam varchar2(50):=',pageNum,pageSize,pageNum,pageSize';
begin
  --填写内容;这部分内容自行修改
  v_qid:='query-user';
  v_comments:='加载sql到缓存';
  entitySql:='select *from(select t.*,rownum as rn from tb_user t where id=? and rownum<=?*?)'
  ||' where rn>(?-1)*?';
  countSql:='select count(1) from tb_user where id=?';
  countParam:='id';
  entityParam:=countParam||pageParam;
  v_stats:='ENABLE';--只能是ENABLE或者DISABLE
  --判断并插入数据;这部分代码最好不要修改
  select count(1) into exist from tb_query where QID=v_qid;
  if exist=0 then
    begin
      insert into tb_query(QID,COMMENTS,ENTITY_SQL,COUNT_SQL,ENTITY_PARAM,COUNT_PARAM,STATS)
      values(v_qid,v_comments,entitySql,countSql,entityParam,countParam,v_stats);
      commit;
      dbms_output.put_line('新增成功');
    end;
  else
    begin
       update tb_query set QID=qid,COMMENTS=v_comments,ENTITY_SQL=entitySql,ENTITY_PARAM=entityParam,
      COUNT_SQL=countSql,COUNT_PARAM=countParam,STATS=v_stats,UPDATE_DATE=sysdate
      where QID=v_qid;
      commit;
      dbms_output.put_line('修改成功');
    end;
  end if;
end;
