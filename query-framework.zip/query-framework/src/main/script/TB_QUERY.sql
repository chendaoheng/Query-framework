-- Create table
create table TB_QUERY
(
  qid          VARCHAR2(20) not null,
  comments     VARCHAR2(100) not null,
  entity_sql   VARCHAR2(4000),
  count_sql    VARCHAR2(4000),
  entity_param VARCHAR2(1000),
  count_param  VARCHAR2(1000),
  stats        VARCHAR2(8) not null,
  create_date  DATE default sysdate not null,
  update_date  DATE default sysdate not null
);
-- Add comments to the table
comment on table TB_QUERY
  is '查询框架SQL表';
-- Add comments to the columns
comment on column TB_QUERY.qid
  is '查询ID唯一主键';
comment on column TB_QUERY.comments
  is '功能说明';
comment on column TB_QUERY.entity_sql
  is '查询实体SQL';
comment on column TB_QUERY.count_sql
  is '查询条数SQL';
comment on column TB_QUERY.entity_param
  is '查询实体参数（多个参数用英文逗号隔开）';
comment on column TB_QUERY.count_param
  is '查询条数参数（多个参数用英文逗号隔开）';
comment on column TB_QUERY.stats
  is '状态（ENABLE,DISABLE）';
comment on column TB_QUERY.create_date
  is '创建日期';
comment on column TB_QUERY.update_date
  is '修改日期';
-- Create/Recreate primary, unique and foreign key constraints
alter table TB_QUERY
  add constraint TB_QUERY_PK primary key (QID)
  using index;
-- Create/Recreate check constraints
alter table TB_QUERY
  add constraint CHECK_STATS
  check (STATS IN ('ENABLE','DISABLE'));

